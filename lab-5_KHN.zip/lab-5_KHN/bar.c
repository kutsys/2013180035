#include "function.h"
void InBar() {
    printf("I'm InBar Function\n");
}
