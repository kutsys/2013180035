#include "function.h"
int main(void) {
    InFoo();
    InBoo();
    InBar();
    return 0;
}
