#include "function.h"
void InFoo() {
    printf("I'm InFoo Function\n");
}
