#include "function.h"
void InBoo() {
    printf("I'm InBoo Function\n");
}
